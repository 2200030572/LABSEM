package com.klef.jfsd.exam.severs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.exam.modal.Car;
import com.klef.jfsd.exam.modal.Truck;
import com.klef.jfsd.exam.reprostry.CarRepository;
import com.klef.jfsd.exam.reprostry.TruckRepository;

@Service
public class VehicleService {

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private TruckRepository truckRepository;

    public Car saveCar(Car car) {
        return carRepository.save(car);
    }

    public Truck saveTruck(Truck truck) {
        return truckRepository.save(truck);
    }
}
