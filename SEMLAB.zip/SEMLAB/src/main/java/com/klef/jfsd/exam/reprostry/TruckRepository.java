package com.klef.jfsd.exam.reprostry;


import org.springframework.data.jpa.repository.JpaRepository;

import com.klef.jfsd.exam.modal.Truck;

public interface TruckRepository extends JpaRepository<Truck, Integer> {
}
