package com.klef.jfsd.exam.reprostry;


import org.springframework.data.jpa.repository.JpaRepository;

import com.klef.jfsd.exam.modal.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Integer> {
}
