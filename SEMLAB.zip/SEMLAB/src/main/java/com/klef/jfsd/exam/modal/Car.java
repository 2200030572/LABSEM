package com.klef.jfsd.exam.modal;

import jakarta.persistence.Entity;
import lombok.Data;

@Entity
@Data
public class Car extends Vehicle {
    private int numberOfDoors;

}
