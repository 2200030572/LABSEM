package com.klef.jfsd.exam.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.klef.jfsd.exam.modal.Car;
import com.klef.jfsd.exam.modal.Truck;
import com.klef.jfsd.exam.severs.VehicleService;

@RestController
@RequestMapping("/vehicles")
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @PostMapping("/cars")
    public Car saveCar(@RequestBody Car car) {
        return vehicleService.saveCar(car);
    }

    @PostMapping("/trucks")
    public Truck saveTruck(@RequestBody Truck truck) {
        return vehicleService.saveTruck(truck);
    }
}

